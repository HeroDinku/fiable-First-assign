import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiableAssigComponent } from './fiable-assig.component';

describe('FiableAssigComponent', () => {
  let component: FiableAssigComponent;
  let fixture: ComponentFixture<FiableAssigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FiableAssigComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FiableAssigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
