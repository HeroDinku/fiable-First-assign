import { Component, OnInit } from '@angular/core';
import { Angular } from './angular';

@Component({
  selector: 'app-fiable-assig',
  templateUrl: './fiable-assig.component.html',
  styleUrls: ['./fiable-assig.component.css']
})
export class FiableAssigComponent implements OnInit {
  angular:Angular[]; 
  constructor() {
    this.angular=[
      new Angular("F1234", "Dinku",10000,"Server", 6, "Yes"),
      new Angular("F1235", "Ashe",11000,"Developer", 8, "Yes"),
      new Angular("F1236", "Amar",12000,"Developer", 6, "Yes"),
      new Angular("F1237", "Hera",7500,"Server", 5, "no"),
      new Angular("F1238", "Sunny",14000,"Marketing", 6, "Yes"),
      new Angular("F1239", "David",1500,"Cyber", 2, "no"),
  
    ];
   }



  ngOnInit(): void {
  }

}
