export class Angular {
    constructor ( 
        public Eid :string,
        public Name:string,
        public Salary: number,
        public Designation:string,
        public Credits:number,
        public Promotion:string,

    ) {}
        
    
} 
