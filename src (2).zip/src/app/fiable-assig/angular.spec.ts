import { Angular } from './angular';

describe('Angular', () => {
  it('should create an instance', () => {
    expect(new Angular()).toBeTruthy();
  });
});
